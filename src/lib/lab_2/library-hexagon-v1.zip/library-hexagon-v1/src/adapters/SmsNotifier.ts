import { MemberNotifier } from "../core/MemberNotifier";

/**
 * ADAPTER: notifies members by SMS.
 * (Simulated: messages are printed to the console.)
 */
export class SmsNotifier implements MemberNotifier {
  notifyLoan(memberId: string, bookId: string): void {
    console.log(`[SMS] To member ${memberId}: you borrowed book ${bookId}.`);
  }
}
