import { LoanLimitReachedError } from "../core/LoanLimitReachedError";
import { LoanService } from "../core/LoanService";

export interface BorrowRequest {
  memberId: string;
  bookId: string;
}

export interface HttpResponse {
  status: number;
  body: unknown;
}

/**
 * ADAPTER: handles HTTP requests for loans.
 * (Simulated: requests are plain objects instead of real HTTP calls.)
 */
export class LoanController {
  constructor(private readonly loanService: LoanService) {}

  borrow(request: BorrowRequest): HttpResponse {
    if (!request.memberId || !request.bookId) {
      return { status: 400, body: { error: "memberId and bookId are required" } };
    }

    try {
      const loan = this.loanService.borrowBook(request.memberId, request.bookId);
      return { status: 201, body: loan };
    } catch (error) {
      if (error instanceof LoanLimitReachedError) {
        return { status: 409, body: { error: error.message } };
      }
      throw error;
    }
  }
}
