export class LoanLimitReachedError extends Error {
  constructor(memberId: string, limit: number) {
    super(`Member ${memberId} already has ${limit} active loans`);
    this.name = "LoanLimitReachedError";
  }
}
