import { Loan } from "./Loan";
import { LoanLimitReachedError } from "./LoanLimitReachedError";
import { LoanRepository } from "./LoanRepository";
import { MemberNotifier } from "./MemberNotifier";

const MAX_ACTIVE_LOANS = 3;

export class LoanService {
  constructor(
    private readonly repository: LoanRepository,
    private readonly notifier: MemberNotifier,
  ) {}

  getActiveLoans(memberId: string): Loan[] {
    return this.repository.findActiveByMember(memberId);
  }

  borrowBook(memberId: string, bookId: string): Loan {
    const activeLoans = this.repository.findActiveByMember(memberId);
    if (activeLoans.length >= MAX_ACTIVE_LOANS) {
      throw new LoanLimitReachedError(memberId, MAX_ACTIVE_LOANS);
    }

    const loan = this.repository.save(memberId, bookId);
    this.notifier.notifyLoan(memberId, bookId);
    return loan;
  }
}
