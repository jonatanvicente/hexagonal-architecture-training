import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { Loan } from "../src/core/Loan";
import { LoanLimitReachedError } from "../src/core/LoanLimitReachedError";
import { LoanRepository } from "../src/core/LoanRepository";
import { LoanService } from "../src/core/LoanService";
import { MemberNotifier } from "../src/core/MemberNotifier";

// Simple in-memory fakes: no database, no email.
class FakeLoanRepository implements LoanRepository {
  readonly loans: Loan[] = [];

  save(memberId: string, bookId: string): Loan {
    const loan: Loan = {
      id: `L-${this.loans.length + 1}`,
      memberId,
      bookId,
      borrowedAt: new Date(),
      returned: false,
    };
    this.loans.push(loan);
    return loan;
  }

  findActiveByMember(memberId: string): Loan[] {
    return this.loans.filter((l) => l.memberId === memberId && !l.returned);
  }
}

class FakeNotifier implements MemberNotifier {
  readonly notifications: string[] = [];

  notifyLoan(memberId: string, bookId: string): void {
    this.notifications.push(`${memberId}:${bookId}`);
  }
}

describe("LoanService", () => {
  it("rejects a 4th active loan for the same member", () => {
    const service = new LoanService(new FakeLoanRepository(), new FakeNotifier());
    service.borrowBook("M-1", "B-1");
    service.borrowBook("M-1", "B-2");
    service.borrowBook("M-1", "B-3");

    assert.throws(() => service.borrowBook("M-1", "B-4"), LoanLimitReachedError);
  });
});
