# Library Platform

The library app grows from one hexagon into a **platform of several hexagons**
that live in the same codebase (a *modular monolith*).

Today only **Lending** exists (the result of the Final Project). In Lab 5 you add
**Catalog** and **Fines**, and connect the three.

## Requirements

- Node.js 22.13 or later (uses the built-in `node:sqlite` module)

## Setup

```bash
npm install
git init && git add . && git commit -m "Start Lab 5"
```

## Run

```bash
npm start
```

Then, in another terminal:

```bash
# borrow a book (copy the "id" from the response)
curl -s -X POST http://localhost:3000/loans \
  -H "Content-Type: application/json" -H "x-api-key: dev-key" \
  -d '{"memberId":"M-1","bookId":"B-100"}'

# return it
curl -s -X POST http://localhost:3000/returns \
  -H "Content-Type: application/json" -H "x-api-key: dev-key" \
  -d '{"loanId":"<id>"}'
```

Environment variables: `PORT` (3000), `API_KEY` (dev-key), `DB_PATH` (library.db), `NOTIFIER` (email | sms).

## Commands

```bash
npm test                  # all tests
npm run test:unit         # shared kernel + domain + application of every hexagon
npm run test:integration  # platform, adapters and port contracts
npm run test:e2e          # whole platform through HTTP
npm run typecheck         # type check
npm run check:arch        # architecture rules (scripts/check-arch.ts)
npm run check             # typecheck + check:arch + all tests: run it before every commit
npm run metrics           # code metrics per hexagon, including coupling between hexagons
```

## Structure

```
src/
  shared/                  SHARED KERNEL: used by every hexagon, depends on nothing
    kernel/                MemberId, BookId, DomainError, Clock
    events/                DomainEvent, EventPublisher (port)
  platform/                GENERIC INFRASTRUCTURE: knows no hexagon
    http/                  HTTP server; each hexagon plugs in its routes
    events/                InMemoryEventBus
  lending/                 HEXAGON: borrow and return books
    domain/                Loan, LoanPolicy, Fine, FinePolicy, errors
    application/           BorrowBookService, ReturnBookService
    events/                LoanClosed            <- PUBLIC: other hexagons may use it
    ports/in/              BorrowBookUseCase, ReturnBookUseCase   <- PUBLIC
    ports/out/             LoanRepository, MemberNotifier
    adapters/in/http/      lendingRoutes
    adapters/in/events/    event handlers
    adapters/out/          SQLite, email, SMS
    lendingModule.ts       wiring of this hexagon
  catalog/                 HEXAGON (empty): you build it in Lab 5
  fines/                   HEXAGON (empty): you build it in Lab 5
  app.ts                   COMPOSITION ROOT: creates every module and the HTTP server
  main.ts                  reads the configuration and starts the server
scripts/
  check-arch.ts            architecture rules
  metrics.ts               code metrics
test/
  shared/ platform/ lending/ e2e/ support/
```

## Rules of the platform

1. Inside a hexagon, dependencies point inward: `adapters → application → ports → domain`.
2. A hexagon may use another hexagon **only through its public contract**:
   its driving ports (`ports/in`) and its events (`events`), and only from its
   adapters or its module file.
3. Each hexagon owns its tables (`lending_*`, `catalog_*`, `fines_*`). No hexagon
   reads another hexagon's tables.
4. `shared/` and `platform/` know no hexagon.

## Writing end-to-end tests

`test/e2e/helpers.ts` starts the whole platform with an in-memory database:

```ts
const server = await startTestServer({ today: TODAY });
const loan = await post(server.baseUrl, "/loans", { memberId: "M-1", bookId: "B-1" });

server.setToday(daysAfter(TODAY, 17)); // 3 days after the due date
const result = await post(server.baseUrl, "/returns", { loanId: loan.body.id });

await server.close();
```
