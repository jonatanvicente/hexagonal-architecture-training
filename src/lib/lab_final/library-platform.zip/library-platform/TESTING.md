# Testing strategy

## Test pyramid (start of Lab 5)

| Level | Folders | Tests | What it protects |
|---|---|---|---|
| End to end | `test/e2e` | 5 | the wiring of the whole platform |
| Integration + contract | `test/platform`, `test/*/adapters`, `test/*/contracts` | 12 | technical details: SQLite, event bus, port contracts |
| Unit | `test/shared`, `test/*/domain`, `test/*/application` | 26 | the business rules |

All tests run locally with no external services: SQLite runs in memory and the HTTP
server listens on a random free port (port 0).

## Known issues

- **Dual write:** the loan is saved before the event handlers run. If a handler
  fails, the loan stays saved but the request fails. Solution: Transactional Outbox.
