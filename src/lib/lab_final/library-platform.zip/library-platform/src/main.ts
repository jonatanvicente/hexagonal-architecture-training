import { createApp } from "./app";
import { SmsNotifier } from "./lending/adapters/out/notification/SmsNotifier";
import { SmtpEmailSender } from "./lending/adapters/out/notification/SmtpEmailSender";

// Reads the configuration and starts the app. All the wiring is in app.ts.
const port = Number(process.env.PORT ?? 3000);

const app = createApp({
  dbPath: process.env.DB_PATH ?? "library.db",
  apiKey: process.env.API_KEY ?? "dev-key",
  notifier: process.env.NOTIFIER === "sms" ? new SmsNotifier() : new SmtpEmailSender(),
});

app.server.listen(port, () => {
  console.log(`Library Platform listening on http://localhost:${port}`);
});
