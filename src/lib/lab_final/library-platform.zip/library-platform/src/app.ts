import { Server } from "node:http";
import { DatabaseSync } from "node:sqlite";
import { MemberNotifier } from "./lending/ports/out/MemberNotifier";
import { createLendingModule, LendingModule } from "./lending/lendingModule";
import { InMemoryEventBus } from "./platform/events/InMemoryEventBus";
import { createHttpServer } from "./platform/http/HttpServer";
import { Clock, systemClock } from "./shared/kernel/Clock";

export interface AppConfig {
  dbPath: string;
  apiKey: string;
  notifier: MemberNotifier;
  clock?: Clock;
}

export interface App {
  server: Server;
  events: InMemoryEventBus;
  lending: LendingModule;
  /** Closes the database. Call it after the server is closed. */
  shutdown(): void;
}

/**
 * COMPOSITION ROOT: the only place that knows every hexagon.
 * It creates the shared infrastructure, each hexagon module, and the HTTP server.
 */
export function createApp(config: AppConfig): App {
  const clock = config.clock ?? systemClock;
  const db = new DatabaseSync(config.dbPath);
  const events = new InMemoryEventBus();

  const lending = createLendingModule({ db, events, clock, notifier: config.notifier });

  const server = createHttpServer({
    apiKey: config.apiKey,
    routes: [...lending.routes],
  });

  return { server, events, lending, shutdown: () => db.close() };
}
