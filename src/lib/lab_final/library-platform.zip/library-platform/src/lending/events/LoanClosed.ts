import { DomainEvent } from "../../shared/events/DomainEvent";

/**
 * Published by Lending when a book is returned.
 * Part of the PUBLIC contract of the Lending hexagon: other hexagons may subscribe to it.
 */
export interface LoanClosed extends DomainEvent {
  readonly type: "LoanClosed";
  readonly loanId: string;
  readonly memberId: string;
  readonly fineCents: number;
}
