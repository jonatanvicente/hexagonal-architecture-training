import { Fine } from "./Fine";
import { Loan } from "./Loan";

/**
 * Domain service: calculates the fine for returning a loan late.
 * 50 cents per day late, capped at 10 euros.
 */
export class FinePolicy {
  static readonly CENTS_PER_DAY = 50;
  static readonly MAX_CENTS = 1000;

  fineFor(loan: Loan, today: Date): Fine {
    const cents = loan.daysLate(today) * FinePolicy.CENTS_PER_DAY;
    return Fine.ofCents(Math.min(cents, FinePolicy.MAX_CENTS));
  }
}
