import { InvalidValueError } from "../../shared/kernel/DomainError";

/** Value object: an amount of money owed, stored in cents to avoid float errors. */
export class Fine {
  private constructor(readonly cents: number) {}

  static zero(): Fine {
    return new Fine(0);
  }

  static ofCents(cents: number): Fine {
    if (!Number.isInteger(cents) || cents < 0) {
      throw new InvalidValueError(`Invalid fine: ${cents} cents`);
    }
    return new Fine(cents);
  }

  isZero(): boolean {
    return this.cents === 0;
  }

  toEuros(): number {
    return this.cents / 100;
  }

  equals(other: Fine): boolean {
    return this.cents === other.cents;
  }
}
