import { DomainError } from "../../shared/kernel/DomainError";

export class LoanNotAllowedError extends DomainError {}

export class LoanAlreadyClosedError extends DomainError {}

export class LoanNotFoundError extends DomainError {}
