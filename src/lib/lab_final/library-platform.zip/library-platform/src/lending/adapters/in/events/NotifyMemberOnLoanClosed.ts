import { MemberId } from "../../../../shared/kernel/MemberId";
import { Fine } from "../../../domain/Fine";
import { LoanClosed } from "../../../events/LoanClosed";
import { MemberNotifier } from "../../../ports/out/MemberNotifier";

/** ADAPTER (driving): reacts to LoanClosed by notifying the member. */
export class NotifyMemberOnLoanClosed {
  constructor(private readonly notifier: MemberNotifier) {}

  handle(event: LoanClosed): void {
    this.notifier.notifyLoanClosed(MemberId.of(event.memberId), event.loanId, Fine.ofCents(event.fineCents));
  }
}
