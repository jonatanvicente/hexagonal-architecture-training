import { LoanClosed } from "../../../events/LoanClosed";

/**
 * ADAPTER (driving): reacts to LoanClosed by logging the fine, if any.
 * Temporary: fines should become their own hexagon.
 */
export class LogFinesOnLoanClosed {
  constructor(private readonly log: (line: string) => void = console.log) {}

  handle(event: LoanClosed): void {
    if (event.fineCents > 0) {
      this.log(`[FINES] ${event.memberId} owes €${(event.fineCents / 100).toFixed(2)}`);
    }
  }
}
