import { HttpResponse, Route } from "../../../../platform/http/HttpServer";
import { BookId } from "../../../../shared/kernel/BookId";
import { InvalidValueError } from "../../../../shared/kernel/DomainError";
import { MemberId } from "../../../../shared/kernel/MemberId";
import { LoanAlreadyClosedError, LoanNotAllowedError, LoanNotFoundError } from "../../../domain/LendingErrors";
import { Loan } from "../../../domain/Loan";
import { BorrowBookUseCase } from "../../../ports/in/BorrowBookUseCase";
import { ReturnBookUseCase } from "../../../ports/in/ReturnBookUseCase";

export interface LendingUseCases {
  borrowBook: BorrowBookUseCase;
  returnBook: ReturnBookUseCase;
}

/**
 * ADAPTER (driving): the HTTP API of the Lending hexagon.
 *
 * POST /loans     { "memberId": "M-1", "bookId": "B-100" }  -> 201 | 409
 * POST /returns   { "loanId": "..." }                         -> 200 | 404 | 409
 */
export function lendingRoutes(useCases: LendingUseCases): Route[] {
  return [
    {
      method: "POST",
      path: "/loans",
      handle: ({ body }) =>
        translateErrors(() => {
          const memberId = MemberId.of(String(body.memberId ?? ""));
          const bookId = BookId.of(String(body.bookId ?? ""));
          const loan = useCases.borrowBook.borrow(memberId, bookId);
          return { status: 201, body: toLoanResponse(loan) };
        }),
    },
    {
      method: "POST",
      path: "/returns",
      handle: ({ body }) =>
        translateErrors(() => {
          const loanId = body.loanId;
          if (typeof loanId !== "string" || loanId === "") {
            throw new InvalidValueError("loanId is required");
          }
          const fine = useCases.returnBook.returnBook(loanId);
          return { status: 200, body: { loanId, status: "CLOSED", fineEuros: fine.toEuros() } };
        }),
    },
  ];
}

/** Exception translation: domain errors -> HTTP status codes. */
function translateErrors(action: () => HttpResponse): HttpResponse {
  try {
    return action();
  } catch (error) {
    if (error instanceof LoanNotFoundError) {
      return { status: 404, body: { error: error.message } };
    }
    if (error instanceof LoanNotAllowedError || error instanceof LoanAlreadyClosedError) {
      return { status: 409, body: { error: error.message } };
    }
    throw error;
  }
}

function toLoanResponse(loan: Loan) {
  return {
    id: loan.id,
    memberId: loan.memberId.value,
    bookId: loan.bookId.value,
    dueDate: loan.dueDate.toISOString(),
    status: loan.status,
  };
}
