import { BookId } from "../../shared/kernel/BookId";
import { Clock, systemClock } from "../../shared/kernel/Clock";
import { MemberId } from "../../shared/kernel/MemberId";
import { LoanNotAllowedError } from "../domain/LendingErrors";
import { Loan } from "../domain/Loan";
import { LoanPolicy } from "../domain/LoanPolicy";
import { BorrowBookUseCase } from "../ports/in/BorrowBookUseCase";
import { LoanRepository } from "../ports/out/LoanRepository";
import { MemberNotifier } from "../ports/out/MemberNotifier";

/** Application service: orchestrates "borrow a book". No business rules here. */
export class BorrowBookService implements BorrowBookUseCase {
  constructor(
    private readonly loans: LoanRepository,
    private readonly notifier: MemberNotifier,
    private readonly policy: LoanPolicy = new LoanPolicy(),
    private readonly clock: Clock = systemClock,
  ) {}

  borrow(memberId: MemberId, bookId: BookId): Loan {
    const today = this.clock();
    const openLoans = this.loans.findOpenLoansOf(memberId);

    if (!this.policy.canBorrow(openLoans, today)) {
      throw new LoanNotAllowedError(`Member ${memberId} cannot borrow more books right now`);
    }

    const loan = Loan.open(this.loans.nextId(), memberId, bookId, today);
    this.loans.save(loan);
    this.notifier.notifyLoanOpened(loan);
    return loan;
  }
}
