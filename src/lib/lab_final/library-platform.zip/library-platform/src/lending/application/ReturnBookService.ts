import { EventPublisher } from "../../shared/events/EventPublisher";
import { Clock, systemClock } from "../../shared/kernel/Clock";
import { Fine } from "../domain/Fine";
import { FinePolicy } from "../domain/FinePolicy";
import { LoanNotFoundError } from "../domain/LendingErrors";
import { LoanClosed } from "../events/LoanClosed";
import { ReturnBookUseCase } from "../ports/in/ReturnBookUseCase";
import { LoanRepository } from "../ports/out/LoanRepository";

/** Application service: orchestrates "return a book". No business rules here. */
export class ReturnBookService implements ReturnBookUseCase {
  constructor(
    private readonly loans: LoanRepository,
    private readonly events: EventPublisher,
    private readonly finePolicy: FinePolicy = new FinePolicy(),
    private readonly clock: Clock = systemClock,
  ) {}

  returnBook(loanId: string): Fine {
    const today = this.clock();
    const loan = this.loans.findById(loanId);
    if (!loan) {
      throw new LoanNotFoundError(`Loan ${loanId} does not exist`);
    }

    loan.close();
    const fine = this.finePolicy.fineFor(loan, today);
    this.loans.save(loan);

    const event: LoanClosed = {
      type: "LoanClosed",
      loanId: loan.id,
      memberId: loan.memberId.value,
      fineCents: fine.cents,
      occurredAt: today.toISOString(),
    };
    this.events.publish(event);
    return fine;
  }
}
