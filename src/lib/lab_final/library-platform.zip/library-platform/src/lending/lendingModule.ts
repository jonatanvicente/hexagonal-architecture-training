import { DatabaseSync } from "node:sqlite";
import { InMemoryEventBus } from "../platform/events/InMemoryEventBus";
import { Route } from "../platform/http/HttpServer";
import { Clock } from "../shared/kernel/Clock";
import { LogFinesOnLoanClosed } from "./adapters/in/events/LogFinesOnLoanClosed";
import { NotifyMemberOnLoanClosed } from "./adapters/in/events/NotifyMemberOnLoanClosed";
import { lendingRoutes } from "./adapters/in/http/lendingRoutes";
import { SqliteLoanRepository } from "./adapters/out/persistence/SqliteLoanRepository";
import { BorrowBookService } from "./application/BorrowBookService";
import { ReturnBookService } from "./application/ReturnBookService";
import { FinePolicy } from "./domain/FinePolicy";
import { LoanPolicy } from "./domain/LoanPolicy";
import { LoanClosed } from "./events/LoanClosed";
import { BorrowBookUseCase } from "./ports/in/BorrowBookUseCase";
import { ReturnBookUseCase } from "./ports/in/ReturnBookUseCase";
import { MemberNotifier } from "./ports/out/MemberNotifier";

export interface LendingDependencies {
  db: DatabaseSync;
  events: InMemoryEventBus;
  clock: Clock;
  notifier: MemberNotifier;
}

/** What the Lending hexagon offers to the rest of the application. */
export interface LendingModule {
  routes: Route[];
  borrowBook: BorrowBookUseCase;
  returnBook: ReturnBookUseCase;
}

/**
 * Wiring of the Lending hexagon: creates its adapters and services
 * and subscribes its event handlers.
 */
export function createLendingModule(deps: LendingDependencies): LendingModule {
  const loans = new SqliteLoanRepository(deps.db);

  const borrowBook = new BorrowBookService(loans, deps.notifier, new LoanPolicy(), deps.clock);
  const returnBook = new ReturnBookService(loans, deps.events, new FinePolicy(), deps.clock);

  const notifyMember = new NotifyMemberOnLoanClosed(deps.notifier);
  const logFines = new LogFinesOnLoanClosed();
  deps.events.subscribe<LoanClosed>("LoanClosed", (e) => notifyMember.handle(e));
  deps.events.subscribe<LoanClosed>("LoanClosed", (e) => logFines.handle(e));

  return {
    routes: lendingRoutes({ borrowBook, returnBook }),
    borrowBook,
    returnBook,
  };
}
