import { BookId } from "../../../shared/kernel/BookId";
import { MemberId } from "../../../shared/kernel/MemberId";
import { Loan } from "../../domain/Loan";

// Driving port.
export interface BorrowBookUseCase {
  borrow(memberId: MemberId, bookId: BookId): Loan;
}
