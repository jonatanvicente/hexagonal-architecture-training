import { Fine } from "../../domain/Fine";

// Driving port.
export interface ReturnBookUseCase {
  /** Closes the loan and returns the fine for returning it late (zero if on time). */
  returnBook(loanId: string): Fine;
}
