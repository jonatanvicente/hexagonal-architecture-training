import { IncomingMessage, Server, ServerResponse, createServer } from "node:http";
import { InvalidValueError } from "../../shared/kernel/DomainError";

export interface HttpRequest {
  /** Values from the path, e.g. { memberId: "M-1" } for "/members/:memberId/balance". */
  params: Record<string, string>;
  body: Record<string, unknown>;
}

export interface HttpResponse {
  status: number;
  body: unknown;
}

export interface Route {
  method: "GET" | "POST";
  /** Path pattern, e.g. "/loans" or "/books/:bookId". */
  path: string;
  handle(request: HttpRequest): HttpResponse;
}

export interface HttpServerOptions {
  apiKey: string;
  routes: Route[];
}

/**
 * Shared HTTP infrastructure. Each hexagon contributes its own routes
 * (its driving HTTP adapter); this server only does the plumbing:
 * routing, JSON, API key, and errors that no route handled.
 *
 * Returns the server WITHOUT starting it, so callers (main or tests) choose the port.
 */
export function createHttpServer(options: HttpServerOptions): Server {
  return createServer(async (req, res) => {
    try {
      const match = findRoute(options.routes, req);
      if (!match) {
        return send(res, { status: 404, body: { error: "Not found" } });
      }
      if (req.headers["x-api-key"] !== options.apiKey) {
        return send(res, { status: 401, body: { error: "Missing or invalid API key" } });
      }
      const body = req.method === "POST" ? await readJson(req) : {};
      return send(res, match.route.handle({ params: match.params, body }));
    } catch (error) {
      if (error instanceof SyntaxError || error instanceof InvalidValueError) {
        return send(res, { status: 400, body: { error: error.message } });
      }
      console.error(error);
      return send(res, { status: 500, body: { error: "Internal server error" } });
    }
  });
}

function findRoute(routes: Route[], req: IncomingMessage) {
  const path = (req.url ?? "/").split("?")[0];
  for (const route of routes) {
    if (route.method !== req.method) continue;
    const params = matchPath(route.path, path);
    if (params) return { route, params };
  }
  return null;
}

function matchPath(pattern: string, path: string): Record<string, string> | null {
  const expected = pattern.split("/");
  const actual = path.split("/");
  if (expected.length !== actual.length) return null;

  const params: Record<string, string> = {};
  for (let i = 0; i < expected.length; i++) {
    if (expected[i].startsWith(":")) {
      params[expected[i].slice(1)] = decodeURIComponent(actual[i]);
    } else if (expected[i] !== actual[i]) {
      return null;
    }
  }
  return params;
}

async function readJson(req: IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  const text = Buffer.concat(chunks).toString("utf8");
  return text ? JSON.parse(text) : {};
}

function send(res: ServerResponse, response: HttpResponse): void {
  res.writeHead(response.status, { "Content-Type": "application/json" });
  res.end(JSON.stringify(response.body));
}
