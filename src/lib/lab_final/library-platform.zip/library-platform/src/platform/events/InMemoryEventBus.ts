import { DomainEvent } from "../../shared/events/DomainEvent";
import { EventPublisher } from "../../shared/events/EventPublisher";

export type EventHandler<E extends DomainEvent> = (event: E) => void;

/**
 * ADAPTER: an in-process event bus.
 * Handlers run synchronously, in the order they subscribed.
 * In production it could be replaced by Kafka, RabbitMQ... without changing the hexagons.
 */
export class InMemoryEventBus implements EventPublisher {
  private readonly handlers = new Map<string, EventHandler<DomainEvent>[]>();

  subscribe<E extends DomainEvent>(type: E["type"], handler: EventHandler<E>): void {
    const list = this.handlers.get(type) ?? [];
    list.push(handler as EventHandler<DomainEvent>);
    this.handlers.set(type, list);
  }

  publish(event: DomainEvent): void {
    for (const handler of this.handlers.get(event.type) ?? []) {
      handler(event);
    }
  }
}
