# Fines hexagon

Empty on purpose: you build it in Lab 5 (exercises 8 to 10).
Follow the same folders as `src/lending`.
