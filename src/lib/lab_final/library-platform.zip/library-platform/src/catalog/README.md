# Catalog hexagon

Empty on purpose: you build it in Lab 5 (exercises 3 to 5 and 7).
Follow the same folders as `src/lending`.
