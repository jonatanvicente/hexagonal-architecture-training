/**
 * Something that happened in one hexagon and that other hexagons may react to.
 * Events cross hexagon boundaries, so they carry only primitive values
 * (strings, numbers, ISO dates), never domain objects.
 */
export interface DomainEvent {
  readonly type: string;
  readonly occurredAt: string; // ISO date
}
