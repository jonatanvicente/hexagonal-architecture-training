import { DomainEvent } from "./DomainEvent";

/** Driven port shared by every hexagon that publishes events. */
export interface EventPublisher {
  publish(event: DomainEvent): void;
}
