/** Base class for every business error, in every hexagon. */
export class DomainError extends Error {
  constructor(message: string) {
    super(message);
    this.name = new.target.name;
  }
}

/** A value does not respect the rules of the domain (bad format, out of range...). */
export class InvalidValueError extends DomainError {}
