# ADR 0002: Migrate returns to the hexagon and fix the legacy quirks

## Status
Accepted (Final Project).

## Context
`POST /returns` was legacy MVC code. Characterization tests captured two quirks:
returning a loan twice answered 200, and an unknown loan answered 500.
No external client depends on these responses.

## Decision
Return books through `ReturnBookService` (Strangler Fig with a toggle, then remove
the legacy code). Fix the quirks: 409 for a loan already returned, 404 for an
unknown loan. Money is stored in cents.

## Consequences
- The legacy folder and the toggle were deleted.
- The characterization tests were changed on purpose to the new status codes.
- Returning a book publishes `LoanClosed`; notifications and fines logging react to it.
