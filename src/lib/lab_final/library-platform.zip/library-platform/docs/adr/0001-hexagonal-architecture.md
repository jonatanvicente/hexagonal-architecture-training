# ADR 0001: Use Hexagonal Architecture

## Status
Accepted (Lab 1).

## Context
The original n-tier app mixed business rules with HTTP, SQL and email code. The
business logic depended on technical details, so it could not change or be tested
without them.

## Decision
Organize the code as a hexagon: business rules in the core, technical details in
adapters, and ports (interfaces owned by the core) between them. Dependencies point
inward. The rules are checked automatically with `npm run check:arch`.

## Consequences
- The core is tested in milliseconds, with no database.
- New adapters (SMS, SQLite, HTTP) are added without changing the core.
- More files and interfaces than the original layered code.
