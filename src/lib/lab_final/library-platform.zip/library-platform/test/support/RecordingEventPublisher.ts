import { DomainEvent } from "../../src/shared/events/DomainEvent";
import { EventPublisher } from "../../src/shared/events/EventPublisher";

/** Fake EventPublisher for any hexagon: records events instead of delivering them. */
export class RecordingEventPublisher implements EventPublisher {
  readonly published: DomainEvent[] = [];

  publish(event: DomainEvent): void {
    this.published.push(event);
  }

  ofType<E extends DomainEvent>(type: E["type"]): E[] {
    return this.published.filter((e) => e.type === type) as E[];
  }
}
