/** Fixed dates for deterministic tests. */
export const TODAY = new Date("2026-01-01T10:00:00Z");

const MS_PER_DAY = 24 * 60 * 60 * 1000;

export function daysAfter(date: Date, days: number): Date {
  return new Date(date.getTime() + days * MS_PER_DAY);
}
