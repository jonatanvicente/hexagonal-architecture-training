import { AddressInfo } from "node:net";
import { App, createApp } from "../../src/app";
import { FakeMemberNotifier } from "../lending/fakes/FakeMemberNotifier";

export const API_KEY = "test-key";

export interface TestServer {
  baseUrl: string;
  app: App;
  notifier: FakeMemberNotifier;
  /** Changes the date the app sees as "today" (e.g. to simulate a late return). */
  setToday(date: Date): void;
  close(): Promise<void>;
}

/** Starts the WHOLE app (every hexagon) with an in-memory database on a random free port. */
export async function startTestServer(options: { today?: Date } = {}): Promise<TestServer> {
  let today = options.today ?? new Date();
  const notifier = new FakeMemberNotifier();
  const app = createApp({ dbPath: ":memory:", apiKey: API_KEY, notifier, clock: () => today });

  await new Promise<void>((resolve) => app.server.listen(0, "127.0.0.1", resolve));
  const { port } = app.server.address() as AddressInfo;

  return {
    baseUrl: `http://127.0.0.1:${port}`,
    app,
    notifier,
    setToday: (date) => {
      today = date;
    },
    close: () =>
      new Promise<void>((resolve, reject) => {
        app.server.closeAllConnections();
        app.server.close((error) => {
          app.shutdown();
          error ? reject(error) : resolve();
        });
      }),
  };
}

export interface ApiResponse {
  status: number;
  body: any;
}

/** Sends a POST request with a JSON body. Pass apiKey: null to omit the header. */
export async function post(baseUrl: string, path: string, body: unknown, apiKey: string | null = API_KEY) {
  return request(baseUrl, "POST", path, body, apiKey);
}

/** Sends a GET request. */
export async function get(baseUrl: string, path: string, apiKey: string | null = API_KEY) {
  return request(baseUrl, "GET", path, undefined, apiKey);
}

async function request(
  baseUrl: string,
  method: string,
  path: string,
  body: unknown,
  apiKey: string | null,
): Promise<ApiResponse> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (apiKey !== null) headers["x-api-key"] = apiKey;
  const response = await fetch(baseUrl + path, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: response.status, body: await response.json() };
}
