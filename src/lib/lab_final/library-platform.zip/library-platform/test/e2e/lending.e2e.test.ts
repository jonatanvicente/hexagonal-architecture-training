import assert from "node:assert/strict";
import { afterEach, beforeEach, describe, it } from "node:test";
import { daysAfter, TODAY } from "../support/dates";
import { post, startTestServer, TestServer } from "./helpers";

describe("Lending (end to end)", () => {
  let server: TestServer;

  beforeEach(async () => {
    server = await startTestServer({ today: TODAY });
  });

  afterEach(async () => {
    await server.close();
  });

  async function borrow(memberId: string, bookId = "B-1") {
    return post(server.baseUrl, "/loans", { memberId, bookId });
  }

  it("borrows a book with a valid API key", async () => {
    const response = await borrow("M-1");

    assert.equal(response.status, 201);
    assert.equal(response.body.status, "OPEN");
  });

  it("rejects a request without an API key", async () => {
    const response = await post(server.baseUrl, "/loans", { memberId: "M-1", bookId: "B-1" }, null);
    assert.equal(response.status, 401);
  });

  it("rejects a 4th loan with 409", async () => {
    for (const book of ["B-1", "B-2", "B-3"]) await borrow("M-1", book);
    assert.equal((await borrow("M-1", "B-4")).status, 409);
  });

  it("returns a book late and reports the fine", async () => {
    const loan = await borrow("M-1");
    server.setToday(daysAfter(TODAY, 17));

    const response = await post(server.baseUrl, "/returns", { loanId: loan.body.id });

    assert.equal(response.status, 200);
    assert.equal(response.body.fineEuros, 1.5);
    assert.equal(server.notifier.closed[0].fineCents, 150);
  });

  it("answers 409 when the loan is returned twice and 404 for an unknown loan", async () => {
    const loan = await borrow("M-1");
    await post(server.baseUrl, "/returns", { loanId: loan.body.id });

    assert.equal((await post(server.baseUrl, "/returns", { loanId: loan.body.id })).status, 409);
    assert.equal((await post(server.baseUrl, "/returns", { loanId: "nope" })).status, 404);
  });
});
