import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { Loan } from "../../../src/lending/domain/Loan";
import { LoanPolicy } from "../../../src/lending/domain/LoanPolicy";
import { BookId } from "../../../src/shared/kernel/BookId";
import { MemberId } from "../../../src/shared/kernel/MemberId";
import { daysAfter, TODAY } from "../../support/dates";

const policy = new LoanPolicy();

function loansOpenedOn(date: Date, count: number): Loan[] {
  return Array.from({ length: count }, (_, i) =>
    Loan.open(`L-${i + 1}`, MemberId.of("M-1"), BookId.of(`B-${i + 1}`), date),
  );
}

describe("LoanPolicy", () => {
  it("allows borrowing under the limit", () => {
    assert.equal(policy.canBorrow(loansOpenedOn(TODAY, 2), TODAY), true);
  });

  it("rejects borrowing at the limit", () => {
    assert.equal(policy.canBorrow(loansOpenedOn(TODAY, 3), TODAY), false);
  });

  it("rejects borrowing with an overdue loan", () => {
    assert.equal(policy.canBorrow(loansOpenedOn(daysAfter(TODAY, -60), 1), TODAY), false);
  });
});
