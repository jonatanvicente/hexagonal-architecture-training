import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { LoanAlreadyClosedError } from "../../../src/lending/domain/LendingErrors";
import { Loan } from "../../../src/lending/domain/Loan";
import { BookId } from "../../../src/shared/kernel/BookId";
import { MemberId } from "../../../src/shared/kernel/MemberId";
import { daysAfter, TODAY } from "../../support/dates";

function openLoan(): Loan {
  return Loan.open("L-1", MemberId.of("M-1"), BookId.of("B-1"), TODAY);
}

describe("Loan", () => {
  it("has a due date 14 days after it is opened", () => {
    assert.deepEqual(openLoan().dueDate, daysAfter(TODAY, 14));
  });

  it("can be closed when open", () => {
    const loan = openLoan();
    loan.close();
    assert.equal(loan.status, "CLOSED");
  });

  it("cannot be closed twice", () => {
    const loan = openLoan();
    loan.close();
    assert.throws(() => loan.close(), LoanAlreadyClosedError);
  });

  it("is overdue after its due date", () => {
    const loan = openLoan();
    assert.equal(loan.isOverdue(daysAfter(TODAY, 14)), false);
    assert.equal(loan.isOverdue(daysAfter(TODAY, 15)), true);
  });

  it("counts the days late", () => {
    const loan = openLoan();
    assert.equal(loan.daysLate(daysAfter(TODAY, 10)), 0);
    assert.equal(loan.daysLate(daysAfter(TODAY, 17)), 3);
  });
});
