import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { Fine } from "../../../src/lending/domain/Fine";
import { Loan } from "../../../src/lending/domain/Loan";
import { FinePolicy } from "../../../src/lending/domain/FinePolicy";
import { BookId } from "../../../src/shared/kernel/BookId";
import { InvalidValueError } from "../../../src/shared/kernel/DomainError";
import { MemberId } from "../../../src/shared/kernel/MemberId";
import { daysAfter, TODAY } from "../../support/dates";

describe("Fine", () => {
  it("stores money in cents and converts it to euros", () => {
    assert.equal(Fine.ofCents(150).toEuros(), 1.5);
  });

  it("rejects negative or decimal cents", () => {
    assert.throws(() => Fine.ofCents(-1), InvalidValueError);
    assert.throws(() => Fine.ofCents(1.5), InvalidValueError);
  });
});

describe("FinePolicy", () => {
  const policy = new FinePolicy();
  const loan = Loan.open("L-1", MemberId.of("M-1"), BookId.of("B-1"), TODAY); // due on day 14

  it("charges nothing when returned on time", () => {
    assert.ok(policy.fineFor(loan, daysAfter(TODAY, 14)).isZero());
  });

  it("charges 50 cents per day late", () => {
    assert.equal(policy.fineFor(loan, daysAfter(TODAY, 17)).cents, 150);
  });

  it("caps the fine at 10 euros", () => {
    assert.equal(policy.fineFor(loan, daysAfter(TODAY, 54)).cents, 1000);
  });
});
