import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { Loan } from "../../../src/lending/domain/Loan";
import { LoanRepository } from "../../../src/lending/ports/out/LoanRepository";
import { BookId } from "../../../src/shared/kernel/BookId";
import { MemberId } from "../../../src/shared/kernel/MemberId";
import { TODAY } from "../../support/dates";

/** Contract of the LoanRepository port: every implementation must pass it. */
export function loanRepositoryContract(name: string, create: () => LoanRepository): void {
  describe(`LoanRepository contract: ${name}`, () => {
    const m1 = MemberId.of("M-1");
    const m2 = MemberId.of("M-2");

    function newLoan(repository: LoanRepository, memberId: MemberId, bookId: string): Loan {
      return Loan.open(repository.nextId(), memberId, BookId.of(bookId), TODAY);
    }

    it("finds a saved loan by id and by member", () => {
      const repository = create();
      const loan = newLoan(repository, m1, "B-1");
      repository.save(loan);

      assert.equal(repository.findById(loan.id)?.id, loan.id);
      assert.deepEqual(repository.findOpenLoansOf(m1).map((l) => l.id), [loan.id]);
    });

    it("returns null for an unknown id", () => {
      assert.equal(create().findById("unknown"), null);
    });

    it("does not return a closed loan as open", () => {
      const repository = create();
      const loan = newLoan(repository, m1, "B-1");
      repository.save(loan);
      loan.close();
      repository.save(loan);

      assert.equal(repository.findOpenLoansOf(m1).length, 0);
    });

    it("keeps the loans of different members apart", () => {
      const repository = create();
      repository.save(newLoan(repository, m1, "B-1"));
      repository.save(newLoan(repository, m2, "B-2"));

      assert.equal(repository.findOpenLoansOf(m1).length, 1);
      assert.equal(repository.findOpenLoansOf(m2).length, 1);
    });
  });
}
