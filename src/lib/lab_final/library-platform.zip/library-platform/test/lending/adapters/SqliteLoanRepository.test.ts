import assert from "node:assert/strict";
import { beforeEach, describe, it } from "node:test";
import { SqliteLoanRepository } from "../../../src/lending/adapters/out/persistence/SqliteLoanRepository";
import { Loan } from "../../../src/lending/domain/Loan";
import { BookId } from "../../../src/shared/kernel/BookId";
import { MemberId } from "../../../src/shared/kernel/MemberId";
import { TODAY } from "../../support/dates";

describe("SqliteLoanRepository", () => {
  let repository: SqliteLoanRepository;

  // A fresh in-memory database for every test: no shared state, no files on disk.
  beforeEach(() => {
    repository = new SqliteLoanRepository(":memory:");
  });

  it("keeps every field when loading a loan back", () => {
    const loan = Loan.open(repository.nextId(), MemberId.of("M-1"), BookId.of("B-1"), TODAY);
    repository.save(loan);

    const loaded = repository.findById(loan.id);

    assert.equal(loaded?.memberId.value, "M-1");
    assert.equal(loaded?.bookId.value, "B-1");
    assert.deepEqual(loaded?.dueDate, loan.dueDate);
    assert.equal(loaded?.status, "OPEN");
  });

  it("updates the status when a closed loan is saved again", () => {
    const loan = Loan.open(repository.nextId(), MemberId.of("M-1"), BookId.of("B-1"), TODAY);
    repository.save(loan);
    loan.close();
    repository.save(loan);

    assert.equal(repository.findById(loan.id)?.status, "CLOSED");
  });
});
