import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ReturnBookService } from "../../../src/lending/application/ReturnBookService";
import { FinePolicy } from "../../../src/lending/domain/FinePolicy";
import { LoanAlreadyClosedError, LoanNotFoundError } from "../../../src/lending/domain/LendingErrors";
import { Loan } from "../../../src/lending/domain/Loan";
import { LoanClosed } from "../../../src/lending/events/LoanClosed";
import { BookId } from "../../../src/shared/kernel/BookId";
import { MemberId } from "../../../src/shared/kernel/MemberId";
import { daysAfter, TODAY } from "../../support/dates";
import { RecordingEventPublisher } from "../../support/RecordingEventPublisher";
import { FakeLoanRepository } from "../fakes/FakeLoanRepository";

function setup(returnDay: number) {
  const loans = new FakeLoanRepository();
  const events = new RecordingEventPublisher();
  const service = new ReturnBookService(loans, events, new FinePolicy(), () => daysAfter(TODAY, returnDay));
  const loan = Loan.open(loans.nextId(), MemberId.of("M-1"), BookId.of("B-1"), TODAY);
  loans.save(loan);
  return { loans, events, service, loan };
}

describe("ReturnBookService", () => {
  it("closes the loan and publishes LoanClosed with no fine when on time", () => {
    const { loans, events, service, loan } = setup(10);

    const fine = service.returnBook(loan.id);

    assert.ok(fine.isZero());
    assert.equal(loans.findById(loan.id)?.status, "CLOSED");
    const [event] = events.ofType<LoanClosed>("LoanClosed");
    assert.equal(event.loanId, loan.id);
    assert.equal(event.fineCents, 0);
  });

  it("includes the fine in the event when returned late", () => {
    const { events, service, loan } = setup(17);

    service.returnBook(loan.id);

    assert.equal(events.ofType<LoanClosed>("LoanClosed")[0].fineCents, 150);
  });

  it("rejects an unknown loan", () => {
    const { service } = setup(10);
    assert.throws(() => service.returnBook("nope"), LoanNotFoundError);
  });

  it("rejects returning the same loan twice, publishing only once", () => {
    const { events, service, loan } = setup(10);
    service.returnBook(loan.id);

    assert.throws(() => service.returnBook(loan.id), LoanAlreadyClosedError);
    assert.equal(events.published.length, 1);
  });
});
