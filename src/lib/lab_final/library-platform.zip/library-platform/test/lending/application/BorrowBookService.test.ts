import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { BorrowBookService } from "../../../src/lending/application/BorrowBookService";
import { LoanNotAllowedError } from "../../../src/lending/domain/LendingErrors";
import { LoanPolicy } from "../../../src/lending/domain/LoanPolicy";
import { BookId } from "../../../src/shared/kernel/BookId";
import { MemberId } from "../../../src/shared/kernel/MemberId";
import { daysAfter, TODAY } from "../../support/dates";
import { FakeLoanRepository } from "../fakes/FakeLoanRepository";
import { FakeMemberNotifier } from "../fakes/FakeMemberNotifier";

const member = MemberId.of("M-1");

function setup(today: Date = TODAY) {
  const loans = new FakeLoanRepository();
  const notifier = new FakeMemberNotifier();
  const clock = { today };
  const service = new BorrowBookService(loans, notifier, new LoanPolicy(), () => clock.today);
  return { loans, notifier, service, clock };
}

describe("BorrowBookService", () => {
  it("saves a valid loan and notifies the member", () => {
    const { loans, notifier, service } = setup();

    const loan = service.borrow(member, BookId.of("B-1"));

    assert.equal(loans.findById(loan.id), loan);
    assert.deepEqual(notifier.opened, [loan]);
  });

  it("rejects a 4th loan without saving or notifying", () => {
    const { loans, notifier, service } = setup();
    for (const book of ["B-1", "B-2", "B-3"]) service.borrow(member, BookId.of(book));

    assert.throws(() => service.borrow(member, BookId.of("B-4")), LoanNotAllowedError);
    assert.equal(loans.loans.size, 3);
    assert.equal(notifier.opened.length, 3);
  });

  it("rejects a member with an overdue loan", () => {
    const { service, clock } = setup(daysAfter(TODAY, -60));
    service.borrow(member, BookId.of("B-1"));

    clock.today = TODAY;

    assert.throws(() => service.borrow(member, BookId.of("B-2")), LoanNotAllowedError);
  });
});
