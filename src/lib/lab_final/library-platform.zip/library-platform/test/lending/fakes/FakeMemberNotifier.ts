import { Fine } from "../../../src/lending/domain/Fine";
import { Loan } from "../../../src/lending/domain/Loan";
import { MemberNotifier } from "../../../src/lending/ports/out/MemberNotifier";
import { MemberId } from "../../../src/shared/kernel/MemberId";

/** Fake of the MemberNotifier port: records notifications instead of sending them. */
export class FakeMemberNotifier implements MemberNotifier {
  readonly opened: Loan[] = [];
  readonly closed: { memberId: string; loanId: string; fineCents: number }[] = [];

  notifyLoanOpened(loan: Loan): void {
    this.opened.push(loan);
  }

  notifyLoanClosed(memberId: MemberId, loanId: string, fine: Fine): void {
    this.closed.push({ memberId: memberId.value, loanId, fineCents: fine.cents });
  }
}
