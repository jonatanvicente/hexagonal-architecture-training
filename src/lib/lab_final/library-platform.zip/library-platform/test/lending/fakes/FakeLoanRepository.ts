import { Loan } from "../../../src/lending/domain/Loan";
import { LoanRepository } from "../../../src/lending/ports/out/LoanRepository";
import { MemberId } from "../../../src/shared/kernel/MemberId";

/** In-memory fake of the LoanRepository port. Checked by the contract tests. */
export class FakeLoanRepository implements LoanRepository {
  readonly loans = new Map<string, Loan>();
  private sequence = 1;

  nextId(): string {
    return `L-${this.sequence++}`;
  }

  save(loan: Loan): void {
    this.loans.set(loan.id, loan);
  }

  findById(id: string): Loan | null {
    return this.loans.get(id) ?? null;
  }

  findOpenLoansOf(memberId: MemberId): Loan[] {
    return [...this.loans.values()].filter((loan) => loan.memberId.equals(memberId) && loan.isOpen());
  }
}
