import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { InMemoryEventBus } from "../../src/platform/events/InMemoryEventBus";
import { DomainEvent } from "../../src/shared/events/DomainEvent";

interface Pinged extends DomainEvent {
  type: "Pinged";
  value: number;
}

describe("InMemoryEventBus", () => {
  it("delivers an event to every subscriber of its type, in order", () => {
    const bus = new InMemoryEventBus();
    const received: string[] = [];
    bus.subscribe<Pinged>("Pinged", (e) => received.push(`first:${e.value}`));
    bus.subscribe<Pinged>("Pinged", (e) => received.push(`second:${e.value}`));

    bus.publish({ type: "Pinged", value: 7, occurredAt: "2026-01-01T00:00:00Z" } as Pinged);

    assert.deepEqual(received, ["first:7", "second:7"]);
  });

  it("ignores events nobody subscribed to", () => {
    const bus = new InMemoryEventBus();
    assert.doesNotThrow(() => bus.publish({ type: "Nobody", occurredAt: "2026-01-01T00:00:00Z" }));
  });
});
