import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { BookId } from "../../src/shared/kernel/BookId";
import { InvalidValueError } from "../../src/shared/kernel/DomainError";
import { MemberId } from "../../src/shared/kernel/MemberId";

describe("MemberId", () => {
  it("is created from a valid value", () => {
    assert.equal(MemberId.of("M-1").value, "M-1");
  });

  it("rejects an invalid value", () => {
    assert.throws(() => MemberId.of("XYZ"), InvalidValueError);
  });

  it("is equal to another MemberId with the same value", () => {
    assert.ok(MemberId.of("M-1").equals(MemberId.of("M-1")));
    assert.ok(!MemberId.of("M-1").equals(MemberId.of("M-2")));
  });
});

describe("BookId", () => {
  it("is created from a valid value", () => {
    assert.equal(BookId.of("B-100").value, "B-100");
  });

  it("rejects an invalid value", () => {
    assert.throws(() => BookId.of("M-1"), InvalidValueError);
  });

  it("is equal to another BookId with the same value", () => {
    assert.ok(BookId.of("B-1").equals(BookId.of("B-1")));
  });
});
