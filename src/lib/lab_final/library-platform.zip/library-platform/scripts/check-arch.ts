/**
 * Architecture rules for the Library Platform.
 *
 *   npm run check:arch
 *
 * Reads every import in src/ and checks it against the rules below.
 * Exits with code 1 if any rule is broken, so it can block a commit.
 */
import { readdirSync, readFileSync, statSync } from "node:fs";
import { dirname, join, normalize, relative } from "node:path";
import ts from "typescript";

const SRC = "src";

// ---------------------------------------------------------------------------
// The hexagons of the platform. Every other folder in src/ must be "shared" or "platform".
// TODO (Lab 5, Exercise 2): register the new hexagons here.
const HEXAGONS = ["lending"];
// ---------------------------------------------------------------------------

type Layer = "domain" | "events" | "ports" | "application" | "adapters" | "module";

type Location =
  | { area: "hexagon"; hexagon: string; layer: Layer }
  | { area: "shared" | "platform" | "root" }
  | { area: "unregistered"; folder: string }
  | { area: "external"; name: string };

const CORE_LAYERS: Layer[] = ["domain", "events", "ports", "application"];

/** Layers of the SAME hexagon that each layer may import. */
const SAME_HEXAGON: Record<Layer, Layer[]> = {
  domain: ["domain"],
  events: ["events"],
  ports: ["ports", "domain"],
  application: ["application", "ports", "domain", "events"],
  adapters: ["adapters", "application", "ports", "domain", "events"],
  module: ["module", "adapters", "application", "ports", "domain", "events"],
};

/**
 * May an adapter (or the module file) of one hexagon import this file of ANOTHER hexagon?
 * TODO (Lab 5, Exercise 2): today nothing is allowed. Allow only the PUBLIC contract of
 * the other hexagon: its driving ports (ports/in) and its published events (events).
 */
function isAllowedCrossHexagonImport(_target: { hexagon: string; layer: Layer; path: string }): boolean {
  return false;
}

// ---------------------------------------------------------------------------

function locate(file: string): Location {
  const parts = relative(SRC, file).split(/[\\/]/);
  if (parts.length === 1) return { area: "root" }; // app.ts, main.ts
  const [top, second] = parts;
  if (top === "shared" || top === "platform") return { area: top };
  if (!HEXAGONS.includes(top)) return { area: "unregistered", folder: `src/${top}` };
  if (parts.length === 2) return { area: "hexagon", hexagon: top, layer: "module" };
  return { area: "hexagon", hexagon: top, layer: second as Layer };
}

function check(from: Location, to: Location, toPath: string): string | null {
  if (from.area === "root") return null; // the composition root may import anything

  if (from.area === "shared") {
    return to.area === "shared" ? null : "shared/ may only import shared/";
  }

  if (from.area === "platform") {
    if (to.area === "hexagon" || to.area === "unregistered") {
      return "platform/ is generic infrastructure: it must not know any hexagon";
    }
    return null;
  }

  if (from.area !== "hexagon") return null;

  if (to.area === "external") {
    return CORE_LAYERS.includes(from.layer)
      ? `the core (${from.layer}) must not import libraries or Node modules ("${to.name}")`
      : null;
  }
  if (to.area === "shared") {
    return from.layer === "events" && !toPath.includes("/shared/events/")
      ? "events may only import shared/events (they carry primitive values only)"
      : null;
  }
  if (to.area === "platform") {
    return CORE_LAYERS.includes(from.layer) ? `the core (${from.layer}) must not import platform/` : null;
  }
  if (to.area === "root") return "only the composition root may import app.ts/main.ts";
  if (to.area === "unregistered") return `${to.folder} is not a registered hexagon (see HEXAGONS)`;
  if (to.area !== "hexagon") return null;

  if (to.hexagon === from.hexagon) {
    return SAME_HEXAGON[from.layer].includes(to.layer)
      ? null
      : `${from.layer} must not depend on ${to.layer} (dependencies point inward)`;
  }

  // Import into ANOTHER hexagon.
  if (from.layer !== "adapters" && from.layer !== "module") {
    return `the core of "${from.hexagon}" must not know the hexagon "${to.hexagon}"`;
  }
  return isAllowedCrossHexagonImport({ hexagon: to.hexagon, layer: to.layer, path: toPath })
    ? null
    : `"${from.hexagon}" may only use the public contract of "${to.hexagon}"`;
}

function listFiles(dir: string): string[] {
  return readdirSync(dir).flatMap((entry) => {
    const path = join(dir, entry);
    if (statSync(path).isDirectory()) return listFiles(path);
    return path.endsWith(".ts") ? [path] : [];
  });
}

function importsOf(file: string): string[] {
  const source = ts.createSourceFile(file, readFileSync(file, "utf8"), ts.ScriptTarget.Latest);
  const specifiers: string[] = [];
  source.forEachChild((node) => {
    if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier) {
      specifiers.push((node.moduleSpecifier as ts.StringLiteral).text);
    }
  });
  return specifiers;
}

function resolveTarget(file: string, specifier: string): { location: Location; path: string } {
  if (!specifier.startsWith(".")) {
    return { location: { area: "external", name: specifier }, path: specifier };
  }
  const path = normalize(join(dirname(file), specifier)).replace(/\\/g, "/");
  return { location: locate(path), path: "/" + path };
}

const files = listFiles(SRC);
const violations: string[] = [];
let importCount = 0;

for (const file of files) {
  const from = locate(file);
  if (from.area === "unregistered") {
    violations.push(`${file}\n    ✗ ${from.folder} is not a registered hexagon (see HEXAGONS)`);
    continue;
  }
  for (const specifier of importsOf(file)) {
    importCount++;
    const target = resolveTarget(file, specifier);
    const problem = check(from, target.location, target.path);
    if (problem) violations.push(`${file}\n    imports "${specifier}"\n    ✗ ${problem}`);
  }
}

if (violations.length > 0) {
  console.error(`\n❌ ${violations.length} architecture violation(s):\n`);
  for (const violation of violations) console.error(`  ${violation}\n`);
  process.exit(1);
}

console.log(`✅ Architecture OK (${files.length} files, ${importCount} imports, hexagons: ${HEXAGONS.join(", ")})`);
