/**
 * Simple code metrics for the Library Platform.
 *
 *   npm run metrics
 *
 * For each folder under src/ (each hexagon, shared, platform) it prints:
 *   Files              number of .ts files
 *   Lines              non-empty lines of code
 *   Biggest fn         lines of the longest function (and its name)
 *   Max imports        highest number of imports in a single file
 *   Complexity         decision points: if, case, ?:, &&, ||, ??, loops, catch
 *   Max cplx / fn      highest complexity of a single function
 *   Cross-hex imports  imports that point into ANOTHER hexagon (coupling between hexagons)
 */
import { readdirSync, readFileSync, statSync } from "node:fs";
import { dirname, join, normalize, relative } from "node:path";
import ts from "typescript";

const ROOT = "src";
const NOT_HEXAGONS = ["shared", "platform"];

interface FunctionMetrics {
  name: string;
  lines: number;
  complexity: number;
}

interface FileMetrics {
  file: string;
  lines: number;
  imports: number;
  crossHexagonImports: string[];
  complexity: number;
  functions: FunctionMetrics[];
}

function listFiles(dir: string): string[] {
  return readdirSync(dir).flatMap((entry) => {
    const path = join(dir, entry);
    if (statSync(path).isDirectory()) return listFiles(path);
    return path.endsWith(".ts") ? [path] : [];
  });
}

/** The top folder under src/ ("lending", "shared"...), or null for files in src/ itself. */
function topFolder(path: string): string | null {
  const parts = relative(ROOT, path).split(/[\\/]/);
  return parts.length > 1 ? parts[0] : null;
}

function isHexagon(folder: string | null): folder is string {
  return folder !== null && !NOT_HEXAGONS.includes(folder);
}

function isDecisionPoint(node: ts.Node): boolean {
  if (
    ts.isIfStatement(node) ||
    ts.isCaseClause(node) ||
    ts.isConditionalExpression(node) ||
    ts.isForStatement(node) ||
    ts.isForInStatement(node) ||
    ts.isForOfStatement(node) ||
    ts.isWhileStatement(node) ||
    ts.isDoStatement(node) ||
    ts.isCatchClause(node)
  ) {
    return true;
  }
  if (ts.isBinaryExpression(node)) {
    const op = node.operatorToken.kind;
    return (
      op === ts.SyntaxKind.AmpersandAmpersandToken ||
      op === ts.SyntaxKind.BarBarToken ||
      op === ts.SyntaxKind.QuestionQuestionToken
    );
  }
  return false;
}

function functionName(node: ts.FunctionLikeDeclaration): string {
  if (node.name) return node.name.getText();
  if (ts.isConstructorDeclaration(node)) return "constructor";
  const parent = node.parent;
  if (parent && (ts.isVariableDeclaration(parent) || ts.isPropertyAssignment(parent))) {
    return parent.name.getText();
  }
  return "(anonymous)";
}

function countComplexity(node: ts.Node): number {
  let count = 0;
  const visit = (child: ts.Node) => {
    if (child !== node && ts.isFunctionLike(child)) return; // nested functions count on their own
    if (isDecisionPoint(child)) count++;
    ts.forEachChild(child, visit);
  };
  visit(node);
  return count;
}

function analyzeFile(file: string): FileMetrics {
  const text = readFileSync(file, "utf8");
  const source = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true);
  const lineOf = (pos: number) => source.getLineAndCharacterOfPosition(pos).line;
  const ownFolder = topFolder(file);

  const metrics: FileMetrics = {
    file,
    lines: text.split("\n").filter((line) => line.trim() !== "").length,
    imports: 0,
    crossHexagonImports: [],
    complexity: 0,
    functions: [],
  };

  const visit = (node: ts.Node) => {
    if (ts.isImportDeclaration(node)) {
      metrics.imports++;
      const specifier = (node.moduleSpecifier as ts.StringLiteral).text;
      if (specifier.startsWith(".") && isHexagon(ownFolder)) {
        const target = normalize(join(dirname(file), specifier));
        const targetFolder = topFolder(target);
        if (isHexagon(targetFolder) && targetFolder !== ownFolder) {
          metrics.crossHexagonImports.push(relative(ROOT, target));
        }
      }
    }
    if (isDecisionPoint(node)) metrics.complexity++;
    if (ts.isFunctionLike(node) && "body" in node && node.body) {
      const fn = node as ts.FunctionLikeDeclaration;
      metrics.functions.push({
        name: functionName(fn),
        lines: lineOf(fn.getEnd()) - lineOf(fn.getStart()) + 1,
        complexity: countComplexity(fn),
      });
    }
    ts.forEachChild(node, visit);
  };
  visit(source);
  return metrics;
}

const files = listFiles(ROOT).map(analyzeFile);
const groups = new Map<string, FileMetrics[]>();
for (const file of files) {
  const folder = topFolder(file.file);
  const key = folder ? `src/${folder}` : "src (root)";
  groups.set(key, [...(groups.get(key) ?? []), file]);
}

const rows = [...groups.entries()]
  .sort(([a], [b]) => a.localeCompare(b))
  .map(([folder, list]) => {
    const functions = list.flatMap((f) => f.functions);
    const biggest = functions.reduce<FunctionMetrics | null>(
      (max, fn) => (!max || fn.lines > max.lines ? fn : max),
      null,
    );
    return {
      Folder: folder,
      Files: list.length,
      Lines: list.reduce((sum, f) => sum + f.lines, 0),
      "Biggest fn": biggest ? `${biggest.lines} (${biggest.name})` : "-",
      "Max imports": Math.max(...list.map((f) => f.imports)),
      Complexity: list.reduce((sum, f) => sum + f.complexity, 0),
      "Max cplx / fn": functions.reduce((max, fn) => Math.max(max, fn.complexity), 0),
      "Cross-hex imports": list.reduce((sum, f) => sum + f.crossHexagonImports.length, 0),
    };
  });

console.log("\nCode metrics for src/\n");
console.table(rows);

const top = files
  .flatMap((f) => f.functions.map((fn) => ({ ...fn, file: relative(ROOT, f.file) })))
  .sort((a, b) => b.lines - a.lines)
  .slice(0, 5);
console.log("\nTop 5 biggest functions\n");
console.table(top.map((fn) => ({ Function: fn.name, File: fn.file, Lines: fn.lines, Complexity: fn.complexity })));

const cross = files.flatMap((f) => f.crossHexagonImports.map((to) => ({ From: relative(ROOT, f.file), To: to })));
console.log("\nImports between hexagons\n");
if (cross.length === 0) console.log("  (none)\n");
else console.table(cross);
