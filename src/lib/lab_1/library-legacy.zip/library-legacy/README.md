# Library Loans (legacy)

A small library app that lets members borrow books.

## Requirements

- Node.js 20 or later

## Setup

```bash
npm install
git init && git add . && git commit -m "Initial legacy version"
```

## Run

```bash
npm start
```

## Type check

```bash
npm run typecheck
```
