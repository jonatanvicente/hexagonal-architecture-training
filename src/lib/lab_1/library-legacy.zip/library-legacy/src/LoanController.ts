import { LoanService } from "./LoanService";

export interface BorrowRequest {
  memberId: string;
  bookId: string;
}

export interface HttpResponse {
  status: number;
  body: unknown;
}

const MAX_ACTIVE_LOANS = 3;

/**
 * Handles HTTP requests for loans.
 * (Simulated: requests are plain objects instead of real HTTP calls.)
 */
export class LoanController {
  private readonly loanService = new LoanService();

  borrow(request: BorrowRequest): HttpResponse {
    if (!request.memberId || !request.bookId) {
      return { status: 400, body: { error: "memberId and bookId are required" } };
    }

    const activeLoans = this.loanService.getActiveLoans(request.memberId);
    if (activeLoans.length >= MAX_ACTIVE_LOANS) {
      return {
        status: 409,
        body: { error: `Member already has ${MAX_ACTIVE_LOANS} active loans` },
      };
    }

    const loan = this.loanService.borrowBook(request.memberId, request.bookId);
    return { status: 201, body: loan };
  }
}
