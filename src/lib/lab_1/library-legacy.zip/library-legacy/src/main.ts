import { BorrowRequest, LoanController } from "./LoanController";

const controller = new LoanController();

const requests: BorrowRequest[] = [
  { memberId: "M-1", bookId: "B-100" },
  { memberId: "M-1", bookId: "B-200" },
  { memberId: "M-1", bookId: "B-300" },
  { memberId: "M-1", bookId: "B-400" }, // 4th loan for the same member
  { memberId: "M-2", bookId: "B-100" },
  { memberId: "", bookId: "B-500" }, // invalid request
];

for (const request of requests) {
  console.log(`\nPOST /loans ${JSON.stringify(request)}`);
  const response = controller.borrow(request);
  console.log(`-> ${response.status} ${JSON.stringify(response.body)}`);
}
