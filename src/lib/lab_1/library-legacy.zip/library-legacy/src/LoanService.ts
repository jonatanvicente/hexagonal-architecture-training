import { Loan } from "./Loan";
import { MySqlLoanRepository } from "./MySqlLoanRepository";
import { SmtpEmailSender } from "./SmtpEmailSender";

export class LoanService {
  private readonly repository = new MySqlLoanRepository();
  private readonly emailSender = new SmtpEmailSender();

  getActiveLoans(memberId: string): Loan[] {
    return this.repository.findActiveByMember(memberId);
  }

  borrowBook(memberId: string, bookId: string): Loan {
    const loan = this.repository.save(memberId, bookId);

    this.emailSender.sendEmail(
      `${memberId}@library.local`,
      "New loan",
      `You borrowed book ${bookId}. Please return it within 14 days.`,
    );

    return loan;
  }
}
