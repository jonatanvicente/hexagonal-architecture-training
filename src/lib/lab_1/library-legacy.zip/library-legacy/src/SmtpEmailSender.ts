/**
 * Sends emails through an SMTP server.
 * (Simulated: emails are printed to the console.)
 */
export class SmtpEmailSender {
  constructor(private readonly host: string = "smtp.library.local") {}

  sendEmail(to: string, subject: string, body: string): void {
    console.log(`[SMTP ${this.host}] To: ${to} | Subject: ${subject} | ${body}`);
  }
}
