# Glossary

| Term | Definition |
|---|---|
| Member | A person registered in the library who can borrow books. |
| Book | An item of the library catalog that can be borrowed. |
| Borrow | The action of a member taking a book home. It opens a loan. |
| Loan | The record that a member has a book. It is open or closed. |
| Due date | The date a loan must be returned by: 14 days after it is opened. |
| Return | The action of a member bringing a book back. It closes the loan. |
| Open loan | A loan whose book has not been returned yet. |
| Overdue | An open loan whose due date has passed. |
| Loan limit | A member can have at most 3 open loans. |
