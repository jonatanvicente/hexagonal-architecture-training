import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { SqliteLoanRepository } from "../../src/adapters/out/persistence/SqliteLoanRepository";
import { BookId } from "../../src/core/domain/BookId";
import { Loan } from "../../src/core/domain/Loan";
import { MemberId } from "../../src/core/domain/MemberId";

const TODAY = new Date("2026-01-01T10:00:00Z");
const member = MemberId.of("M-1");

const repository = new SqliteLoanRepository(":memory:");

function newLoan(bookId: string): Loan {
  return Loan.open(repository.nextId(), member, BookId.of(bookId), TODAY);
}

describe("SqliteLoanRepository", () => {
  it("finds a saved loan", () => {
    repository.save(newLoan("B-1"));

    const loans = repository.findOpenLoansOf(member);

    assert.equal(loans.length, 1);
    assert.equal(loans[0].bookId.value, "B-1");
  });

  it("finds all the open loans of a member", () => {
    repository.save(newLoan("B-2"));
    repository.save(newLoan("B-3"));

    const loans = repository.findOpenLoansOf(member);

    assert.equal(loans.length, 2);
  });
});
